/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Ardiansyah Setiajati
 */
public class ConfigDirektori {
    // Ardi
  // public static final String direktoriAkun = "D:\\A-Ardi\\02-IF\\Semester 1\\Algoritma dan Pemrograman\\Tugas\\Project Alpro\\json\\user.json";
  // public static final String direktoriKompetensi = "D:\\A-Ardi\\02-IF\\Semester 1\\Algoritma dan Pemrograman\\Tugas\\Project Alpro\\json\\kompetensi.json";
  // public static final String direktoriPekerjaan = "D:\\A-Ardi\\02-IF\\Semester 1\\Algoritma dan Pemrograman\\Tugas\\Project Alpro\\json\\pekerjaan.json";
    
   
   //Izu

   public static final String direktoriAkun = "/home/izu/NetBeansProjects/tugas-besar-alpro-kelompok-5/json/user.json";
   public static final String direktoriKompetensi = "/home/izu/NetBeansProjects/tugas-besar-alpro-kelompok-5/json/kompetensi.json";
   public static final String direktoriPekerjaan = "/home/izu/NetBeansProjects/tugas-besar-alpro-kelompok-5/json/pekerjaan.json";
   public static final String direktoriKalender = "/home/izu/NetBeansProjects/tugas-besar-alpro-kelompok-5/json/kalender.json";
   public static final String direktoriSlot = "/home/izu/NetBeansProjects/tugas-besar-alpro-kelompok-5/json/jadwal.json";
   public static final String direktoriAlokasiSlot = "/home/izu/NetBeansProjects/tugas-besar-alpro-kelompok-5/json/alokasislot.json";

   
   //fiqri
   //public static final String direktoriAkun = "D:\\Kuliah Pasca\\Alpro\\tugas-besar-alpro-kelompok-5\\json\\user.json";
   //public static final String direktoriKompetensi = "D:\\Kuliah Pasca\\Alpro\\tugas-besar-alpro-kelompok-5\\json\\kompetensi.json";
   //public static final String direktoriPekerjaan = "D:\\Kuliah Pasca\\Alpro\\tugas-besar-alpro-kelompok-5\\json\\pekerjaan.json";
}
